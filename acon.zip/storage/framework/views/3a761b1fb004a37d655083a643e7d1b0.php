<section class="ttm-row blog-section clearfix">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-title style2">
                    <div class="title-header">
                        <h2 class="title">Latest <b>Events and Circulars</b></h2>
                    </div>
                </div>
            </div>
        </div>
        <div class="row slick_slider mb_15" data-slick='{"slidesToShow": 3, "slidesToScroll": 1, "arrows":false, "dots":false, "autoplay":true, "infinite":true, "responsive": [{"breakpoint":1024,"settings":{"slidesToShow": 3}}, {"breakpoint":900,"settings":{"slidesToShow": 2}}, {"breakpoint":575,"settings":{"slidesToShow": 1}}]}'>
            <?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-lg-4">
                    <div class="featured-imagebox featured-imagebox-post style1">
                        <div class="featured-thumbnail">
                            <img class="img-fluid" src="<?php echo e(url($event['image'])); ?>" alt="" height="100%" width="100%">
                        </div>
                        <div class="featured-content">
                            <div class="ttm-box-post-date">
                                <span class="ttm-entry-date">
                                    <time class="entry-date" datetime="<?php echo e($event['created_at']); ?>"><?php echo e(\Carbon\Carbon::parse($event['created_at'])->format('d')); ?><span class="entry-month entry-year"><?php echo e(\Carbon\Carbon::parse($event['created_at'])->format('M')); ?></span></time>
                                </span>
                            </div>
                            <div class="post-meta">
                                <span class="ttm-meta-line byline"><?php echo e($event['author']); ?></span>
                                <span class="ttm-meta-line comments-link"><?php echo e($event['comments_count']); ?> Comments</span>
                            </div>
                            <div class="post-title">
                                <h5><a href="<?php echo e(url($event['url'])); ?>"><?php echo e($event['title']); ?></a></h5>
                            </div>
                            <div class="post-description">
                                <p><?php echo e($event['description']); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>No events found.</p>
            <?php endif; ?>
    </div>
</section>
<?php /**PATH F:\laragon\www\andavarcon\acon\resources\views/components/latest-events-circulars.blade.php ENDPATH**/ ?>