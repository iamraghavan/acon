<?php $__env->startSection('content'); ?>

<?php if (isset($component)) { $__componentOriginal269900abaed345884ce342681cdc99f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal269900abaed345884ce342681cdc99f6 = $attributes; } ?>
<?php $component = App\View\Components\Breadcrumb::resolve(['pageTitle' => 'Messge From the Principal','value1' => 'Home','value2' => 'About','value3' => 'Message From the Principal'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Breadcrumb::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $attributes = $__attributesOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__attributesOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $component = $__componentOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__componentOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>


<div class="site-main">


    <div class="ttm-row sidebar ttm-sidebar-left clearfix">
        <div class="container">
            <!-- row -->
            <div class="row">
                <?php
                $menuItems = [
                    ['title' => 'Vision and Mission', 'url' => '/about/vision-and-mission'],
                    ['title' => 'Message From the Chairman', 'url' => '/about/message-from-the-founder-and-chairman'],
                    ['title' => 'Message From the Secretary', 'url' => '/about/message-from-the-secretary'],
                    ['title' => 'Message From the Principal', 'url' => Request::path()],
                    ['title' => 'History', 'url' => '/about/history'],

                ];

                ?>

            <?php if (isset($component)) { $__componentOriginal4088d25bd82bc725cd179ab6ddc6f4b8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4088d25bd82bc725cd179ab6ddc6f4b8 = $attributes; } ?>
<?php $component = App\View\Components\SidebarMenu::resolve(['menuItems' => $menuItems] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SidebarMenu::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4088d25bd82bc725cd179ab6ddc6f4b8)): ?>
<?php $attributes = $__attributesOriginal4088d25bd82bc725cd179ab6ddc6f4b8; ?>
<?php unset($__attributesOriginal4088d25bd82bc725cd179ab6ddc6f4b8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4088d25bd82bc725cd179ab6ddc6f4b8)): ?>
<?php $component = $__componentOriginal4088d25bd82bc725cd179ab6ddc6f4b8; ?>
<?php unset($__componentOriginal4088d25bd82bc725cd179ab6ddc6f4b8); ?>
<?php endif; ?>

                <div class="col-lg-12 content-area">
                    <div class="ttm-service-single-content-area">
                        <div class="ttm-service-description">
                            <h3>Andavar College Of Nursing - Principal</h3>

                            <div class="padding_top20 padding_bottom20">
                                <div class="ttm_fatured_image-wrapper">
                                    <img class="img-fluid" src="<?php echo e(asset('images/principal.webp')); ?>" alt="Principal-1" height="50%" width="50%">
                                </div>
                            </div>
                            <div class="padding_top20 res-991-padding_top40">
                                <!-- section title -->
                                <div class="section-title">
                                    <div class="title-header">

                                        <h2 class="title text-gradient gradient-6">Andavar College of Nursing - Principal</h2>
                                    </div>
                                    <div class="title-desc text-justify">
                                        <p>As the Principal, it gives me great pleasure to welcome you all. Our college is dedicated to fostering excellence in nursing education, research, and practice.


                                            </p>
                                    </div>
                                    <div class="title-desc text-justify">
                                        <p>
                                            Here, we are committed to providing our students with a supportive learning environment, where they can develop the skills, knowledge, and compassion needed to excel as healthcare professionals. Our experienced faculty members are committed to providing a supportive learning environment and dedicated to helping students reach their full potential and make a positive impact in the healthcare industry.
                                            Whether you are considering joining our college as a student or faculty member, I encourage you to explore our website to learn more about our programs and achievements. Together, we can continue to make a positive impact on the health and well-being of individuals and communities.
                                            Thank you for visiting our College of Nursing website and we look forward to welcoming you into our community and empowering you to achieve your goals in the dynamic field of nursing.</p>
                                    </div>
                                </div><!-- section title end -->
                                <div class="d-flex align-items-center">

                                    <div class="d-inline-block padding_left30">
                                        <label>Warm Regards,</label>
                                        <h2 class="fs-20 mb-0">Dr. P. Gomathi, M.Sc.,(N),Ph.D</h2>
                                        <label>Principal - Andavar College of Nursing</label>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                </div>


            </div><!-- row end -->
        </div>
    </div>


</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\andavarcon\acon\resources\views/pages/about/message-from-the-principal.blade.php ENDPATH**/ ?>