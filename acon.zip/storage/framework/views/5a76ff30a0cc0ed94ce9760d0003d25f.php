<?php
     $contactDetails = [
        'address' => 'Andavar College of Nursing, 125/2a Main Road, Poravacherry Nagapattinam – 611108',
        'email' => 'principal@andavarcon.edu.in',
        'phone' => '04365 245600',
        'hours' => 'Mon to Sat - 9:00am to 6:00pm <br> (Sunday Closed)'
    ];
?>

<div class="col-lg-4 widget-area sidebar-left">
    <aside class="widget widget-nav-menu">
        <ul>
            <?php $__currentLoopData = $menuItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menuItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="<?php echo e(Request::is(trim($menuItem['url'], '/')) ? 'active' : ''); ?>">
                    <a href="<?php echo e(url($menuItem['url'])); ?>"><?php echo e($menuItem['title']); ?></a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </aside>

    <aside class="widget contact-widget with-title">
        <h3 class="widget-title">Get in touch</h3>
        <ul class="contact-widget-wrapper">
            <li><i class="ttm-textcolor-skincolor ti ti-location-pin"></i><?php echo e($contactDetails['address']); ?></li>
            <li><i class="ttm-textcolor-skincolor ti ti-email"></i><a href="mailto:<?php echo e($contactDetails['email']); ?>" target="_blank"><?php echo e($contactDetails['email']); ?></a></li>
            <li><i class="ttm-textcolor-skincolor ti ti-mobile"></i><?php echo e($contactDetails['phone']); ?></li>
            <li><i class="ttm-textcolor-skincolor ti ti-alarm-clock"></i><?php echo $contactDetails['hours']; ?></li>
        </ul>
    </aside>
</div>

<?php /**PATH F:\laragon\www\andavarcon\acon\resources\views/components/sidebar-menu.blade.php ENDPATH**/ ?>