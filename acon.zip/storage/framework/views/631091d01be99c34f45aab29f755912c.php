<!-- resources/views/facilities/classrooms.blade.php -->
<div>
    <h3>Classrooms</h3>
    <p>Our smart classrooms are ventilated with proper lighting. Each classroom has all essentials like desks, benches, chairs, tables, cupboards, racks, and teaching aids with smart class tech.</p>
</div>
<?php /**PATH F:\laragon\www\andavarcon\acon\resources\views/facilities/partials/classrooms.blade.php ENDPATH**/ ?>