<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
   <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Andavar College of Nursing </title>


      <link rel="stylesheet" type="text/css" href="<?php echo e(asset("/css/bootstrap.min.css")); ?>" media="all"/>
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset("/css/animate.css")); ?>" media="all"/>
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset("/css/font-awesome.css")); ?>" media="all"/>
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset("/css/flaticon.css")); ?>" media="all"/>
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset("/css/themify-icons.css")); ?>" media="all"/>
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset("/css/slick.css")); ?>" media="all"/>
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset("/css/prettyPhoto.css")); ?>" media="all/">
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset("/css/shortcodes.css")); ?>" media="all"/>
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset("/css/main.css")); ?>" media="all"/>
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset("/css/megamenu.css")); ?>" media="all"/>
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset("/css/responsive.css")); ?>" media="all"/>


      <style>
        .ttm-service-description > h3 {
            background-image: linear-gradient(120deg, #f857a6 10%, #ef3f6e 100%);
            -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
        }
      </style>

   </head>
   <body>

    <div class="page">


        <?php if (isset($component)) { $__componentOriginal371139be4683378fa30e03f57b6fd258 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal371139be4683378fa30e03f57b6fd258 = $attributes; } ?>
<?php $component = App\View\Components\NavbarComponent::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('navbar-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\NavbarComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal371139be4683378fa30e03f57b6fd258)): ?>
<?php $attributes = $__attributesOriginal371139be4683378fa30e03f57b6fd258; ?>
<?php unset($__attributesOriginal371139be4683378fa30e03f57b6fd258); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal371139be4683378fa30e03f57b6fd258)): ?>
<?php $component = $__componentOriginal371139be4683378fa30e03f57b6fd258; ?>
<?php unset($__componentOriginal371139be4683378fa30e03f57b6fd258); ?>
<?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>

        <?php if (isset($component)) { $__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa = $attributes; } ?>
<?php $component = App\View\Components\Footer::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Footer::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa)): ?>
<?php $attributes = $__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa; ?>
<?php unset($__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa)): ?>
<?php $component = $__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa; ?>
<?php unset($__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa); ?>
<?php endif; ?>

    </div>

    <?php if(session('success')): ?>
    <script>
        // Display success message in an alert
        alert("<?php echo e(session('success')); ?>");
    </script>
<?php endif; ?>


    <script src="<?php echo e(asset("/js/jquery-3.6.0.min.js")); ?>"></script>
    <script src="<?php echo e(asset("/js/jquery-migrate-3.3.2.min.js")); ?>" defer></script>
    <script src="<?php echo e(asset("/js/bootstrap.min.js")); ?>" defer></script>
    <script src="<?php echo e(asset("/js/jquery.easing.js")); ?>" defer></script>
    <script src="<?php echo e(asset("/js/jquery-waypoints.js")); ?>" defer></script>
    <script src="<?php echo e(asset("/js/jquery-validate.js")); ?>" defer></script>
    <script src="<?php echo e(asset("/js/jquery.prettyPhoto.js")); ?>" defer></script>
    <script src="<?php echo e(asset("/js/slick.min.js")); ?>" defer></script>
    <script src="<?php echo e(asset("/js/numinate.min.js")); ?>" defer></script>
    <script src="<?php echo e(asset("/js/imagesloaded.min.js")); ?>" defer></script>
    <script src="<?php echo e(asset("/js/jquery-isotope.js")); ?>" defer></script>
    <script src="<?php echo e(asset("/js/main.js")); ?>" defer></script>


   </body>
</html>
<?php /**PATH F:\laragon\www\andavarcon\acon\resources\views/layouts/app.blade.php ENDPATH**/ ?>