<div class="ttm-page-title-row ttm-bg ttm-bgimage-yes ttm-bgcolor-darkgrey clearfix">
    <div class="ttm-row-wrapper-bg-layer ttm-bg-layer"></div>
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-12">
                <div class="ttm-page-title-row-inner">
                    <div class="page-title-heading">
                        <h2 class="title"><?php echo e($pageTitle); ?></h2>
                    </div>
                    <div class="breadcrumb-wrapper">
                        <?php if($value1): ?>
                        <span>
                            <a title="<?php echo e($value1); ?>"><?php echo e($value1); ?></a>
                        </span>
                        <?php endif; ?>
                        <?php if($value2): ?>
                        <span>
                            <a title="<?php echo e($value2); ?>"><?php echo e($value2); ?></a>
                        </span>
                        <?php endif; ?>
                        <?php if($value3): ?>
                        <span>
                            <a title="<?php echo e($value3); ?>"><?php echo e($value3); ?></a>
                        </span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH F:\laragon\www\andavarcon\acon\resources\views/components/breadcrumb.blade.php ENDPATH**/ ?>