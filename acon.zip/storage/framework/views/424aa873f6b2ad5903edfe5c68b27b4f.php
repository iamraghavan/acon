<?php $__env->startSection('content'); ?>

<?php if (isset($component)) { $__componentOriginal269900abaed345884ce342681cdc99f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal269900abaed345884ce342681cdc99f6 = $attributes; } ?>
<?php $component = App\View\Components\Breadcrumb::resolve(['pageTitle' => 'Vision and Mission','value1' => 'Home','value2' => 'About','value3' => 'Vision and Mission'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Breadcrumb::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $attributes = $__attributesOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__attributesOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $component = $__componentOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__componentOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>


<div class="site-main">


    <div class="ttm-row sidebar ttm-sidebar-left clearfix">
        <div class="container">
            <!-- row -->
            <div class="row">
                <?php
                $menuItems = [
                    ['title' => 'Vision and Mission', 'url' => Request::path()],
                    ['title' => 'Message From the Chairman', 'url' => '/about/message-from-the-founder-and-chairman'],
                    ['title' => 'Message From the Principal', 'url' => '/about/message-from-the-principal'],
                    ['title' => 'Message From the Secretary', 'url' => '/about/message-from-the-secretary'],
                    ['title' => 'History', 'url' => '/about/history'],

                ];

                ?>

            <?php if (isset($component)) { $__componentOriginal4088d25bd82bc725cd179ab6ddc6f4b8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4088d25bd82bc725cd179ab6ddc6f4b8 = $attributes; } ?>
<?php $component = App\View\Components\SidebarMenu::resolve(['menuItems' => $menuItems] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SidebarMenu::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4088d25bd82bc725cd179ab6ddc6f4b8)): ?>
<?php $attributes = $__attributesOriginal4088d25bd82bc725cd179ab6ddc6f4b8; ?>
<?php unset($__attributesOriginal4088d25bd82bc725cd179ab6ddc6f4b8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4088d25bd82bc725cd179ab6ddc6f4b8)): ?>
<?php $component = $__componentOriginal4088d25bd82bc725cd179ab6ddc6f4b8; ?>
<?php unset($__componentOriginal4088d25bd82bc725cd179ab6ddc6f4b8); ?>
<?php endif; ?>

                <div class="col-lg-12 content-area">
                    <div class="ttm-service-single-content-area">
                        <div class="ttm-service-description">
                            <h3>Our Vision - Andavar Nursing College</h3>

                            <div class="padding_top20 padding_bottom20">
                                <div class="ttm_fatured_image-wrapper">
                                    <img class="img-fluid" src="<?php echo e(asset('images/vision.webp')); ?>" alt="vision-1" height="100%" width="100%">
                                </div>
                            </div>
                            <div class="padding_top15 padding_bottom5">

                                <p class="text-justify">Our vision is to set the highest standards of excellence in nursing by fostering professional values, encouraging innovation in nursing practice, and advancing education and research. We are dedicated to cultivating a culture of continuous improvement and leadership in the nursing field, ensuring that our graduates are well-equipped to meet the evolving needs of healthcare and make a significant impact on patient care and the community.</p>

                            </div>

                        </div>
                    </div>
                    <div class="ttm-service-single-content-area mt-4">
                        <div class="ttm-service-description">
                            <h3>Our Mission - Andavar Nursing College</h3>

                            <div class="padding_top20 padding_bottom20">
                                <div class="ttm_fatured_image-wrapper">
                                    <img class="img-fluid" src="<?php echo e(asset('images/mission.webp')); ?>" alt="vision-1" height="100%" width="100%">
                                </div>
                            </div>
                            <div class="padding_top15 padding_bottom5">

                                <p class="text-justify">Our mission is to deliver exceptional education to the future leaders of the nursing profession, fostering both academic excellence and research in the field of nursing. We are committed to offering top-quality nursing education that emphasizes ethical values and aligns with global standards, ensuring our graduates are well-prepared to meet the challenges and opportunities in healthcare.</p>

                            </div>

                        </div>
                    </div>
                </div>


            </div><!-- row end -->
        </div>
    </div>


</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\andavarcon\acon\resources\views/pages/about/vision-and-mission.blade.php ENDPATH**/ ?>