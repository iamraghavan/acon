<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Bumble Bees IT Solutions | Andavar College of Nursing - Web Portal</title>
  <meta name="robots" content="noindex, nofollow">
  <link rel="shortcut icon" type="image/png" href="<?php echo e(asset("/assets/images/logos/favicon.png")); ?>">
  <link rel="stylesheet" href="<?php echo e(asset("/assets/css/styles.min.css")); ?>">
</head>

<body>


    <?php echo $__env->yieldContent('content-dashboard'); ?>




    <script src="<?php echo e(asset("/assets/libs/jquery/dist/jquery.min.js")); ?>"></script>
    <script src="<?php echo e(asset("/assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js")); ?>"></script>
    <script src="<?php echo e(asset("/assets/js/sidebarmenu.js")); ?>"></script>
    <script src="<?php echo e(asset("/assets/js/app.min.js")); ?>"></script>
    <script src="<?php echo e(asset("/assets/libs/apexcharts/dist/apexcharts.min.js")); ?>"></script>
    <script src="<?php echo e(asset("/assets/libs/simplebar/dist/simplebar.js")); ?>"></script>
    <script src="<?php echo e(asset("/assets/js/dashboard.js")); ?>"></script>


</body>
</html>
<?php /**PATH F:\laragon\www\andavarcon\acon\resources\views/admin/layout/apps.blade.php ENDPATH**/ ?>