<?php $__env->startSection('content'); ?>

<?php if (isset($component)) { $__componentOriginal269900abaed345884ce342681cdc99f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal269900abaed345884ce342681cdc99f6 = $attributes; } ?>
<?php $component = App\View\Components\Breadcrumb::resolve(['pageTitle' => 'Messge from the Founder and Chairman','value1' => 'Home','value2' => 'About','value3' => 'Message from the Founder and Chairman'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Breadcrumb::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $attributes = $__attributesOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__attributesOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $component = $__componentOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__componentOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>


<div class="site-main">


    <div class="ttm-row sidebar ttm-sidebar-left clearfix">
        <div class="container">
            <!-- row -->
            <div class="row">
                <?php
                $menuItems = [
                    ['title' => 'Vision and Mission', 'url' => '/about/vision-and-mission'],
                    ['title' => 'Message From the Chairman', 'url' => Request::path()],
                    ['title' => 'Message From the Principal', 'url' => '/about/message-from-the-principal'],
                    ['title' => 'Message From the Secretary', 'url' => '/about/message-from-the-secretary'],
                    ['title' => 'History', 'url' => '/about/history'],

                ];

                ?>

            <?php if (isset($component)) { $__componentOriginal4088d25bd82bc725cd179ab6ddc6f4b8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4088d25bd82bc725cd179ab6ddc6f4b8 = $attributes; } ?>
<?php $component = App\View\Components\SidebarMenu::resolve(['menuItems' => $menuItems] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SidebarMenu::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4088d25bd82bc725cd179ab6ddc6f4b8)): ?>
<?php $attributes = $__attributesOriginal4088d25bd82bc725cd179ab6ddc6f4b8; ?>
<?php unset($__attributesOriginal4088d25bd82bc725cd179ab6ddc6f4b8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4088d25bd82bc725cd179ab6ddc6f4b8)): ?>
<?php $component = $__componentOriginal4088d25bd82bc725cd179ab6ddc6f4b8; ?>
<?php unset($__componentOriginal4088d25bd82bc725cd179ab6ddc6f4b8); ?>
<?php endif; ?>

                <div class="col-lg-12 content-area">
                    <div class="ttm-service-single-content-area">
                        <div class="ttm-service-description">
                            <h3>Andavar College Of Nursing - Chairman</h3>

                            <div class="padding_top20 padding_bottom20">
                                <div class="ttm_fatured_image-wrapper">
                                    <img class="img-fluid" src="<?php echo e(asset('images/chariman.webp')); ?>" alt="Chairman-1" height="100%" width="100%">
                                </div>
                            </div>
                            <div class="padding_top20 res-991-padding_top40">
                                <!-- section title -->
                                <div class="section-title">
                                    <div class="title-header">

                                        <h2 class="title">Andavar College of Nursing - Chairman</b></h2>
                                    </div>
                                    <div class="title-desc">
                                        <p>Wish you a happy and prosperous academic career for all the Parents, Students and the Faculty members of Andavar College of Nursing.
                                            I feel very proud of running this College of Nursing with the sincere and dedicated services of the teaching and non-teaching staff of this college. I wish and pray that everyone should remember,<span class="text-success" style="font-weight: 500"> "A burning candle alone can light another one" </span> as Rabindranath Tagore proclaimed, highlighting the importance of education in the nursing profession.</p>
                                    </div>
                                </div><!-- section title end -->
                                <div class="d-flex align-items-center">

                                    <div class="d-inline-block padding_left30">
                                        <h2 class="fs-20 mb-0">Rtn.S.Natarajan M.Com,</h2>
                                        <label>Wishing you all the best,</label>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                </div>


            </div><!-- row end -->
        </div>
    </div>


</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\andavarcon\acon\resources\views/pages/about/message-from-the-founder-and-chairman.blade.php ENDPATH**/ ?>